class DefaultConfig:
    DEBUG = False
    TESTING = False
    SECRET_KEY = 'nosso-segredinho'

class DevelopmentConfig(DefaultConfig):
    DEBUG = True
    TESTING = True
    ENV = 'development'
    # Faz Flask ativar modo debug via ENV
    FLASK_DEBUG = 1

class ProductionConfig(DefaultConfig):
    DEBUG = False
    ENV = 'production'        